"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/email/route";
exports.ids = ["app/api/email/route"];
exports.modules = {

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ "dns":
/*!**********************!*\
  !*** external "dns" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("dns");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Femail%2Froute&page=%2Fapi%2Femail%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Femail%2Froute.js&appDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Femail%2Froute&page=%2Fapi%2Femail%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Femail%2Froute.js&appDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_buzac_Projects_Work_ImperialLux_src_app_api_email_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/email/route.js */ \"(rsc)/./src/app/api/email/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/email/route\",\n        pathname: \"/api/email\",\n        filename: \"route\",\n        bundlePath: \"app/api/email/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\buzac\\\\Projects\\\\Work\\\\ImperialLux\\\\src\\\\app\\\\api\\\\email\\\\route.js\",\n    nextConfigOutput,\n    userland: C_Users_buzac_Projects_Work_ImperialLux_src_app_api_email_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/email/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZlbWFpbCUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGZW1haWwlMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZlbWFpbCUyRnJvdXRlLmpzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNidXphYyU1Q1Byb2plY3RzJTVDV29yayU1Q0ltcGVyaWFsTHV4JTVDc3JjJTVDYXBwJnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMmcm9vdERpcj1DJTNBJTVDVXNlcnMlNUNidXphYyU1Q1Byb2plY3RzJTVDV29yayU1Q0ltcGVyaWFsTHV4JmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBc0c7QUFDdkM7QUFDYztBQUM2QjtBQUMxRztBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsZ0hBQW1CO0FBQzNDO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsWUFBWTtBQUNaLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxRQUFRLGlFQUFpRTtBQUN6RTtBQUNBO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ3VIOztBQUV2SCIsInNvdXJjZXMiOlsid2VicGFjazovL2ltcGVyaWFsLWx1eC8/NjAzMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBSb3V0ZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvYXBwLXJvdXRlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJDOlxcXFxVc2Vyc1xcXFxidXphY1xcXFxQcm9qZWN0c1xcXFxXb3JrXFxcXEltcGVyaWFsTHV4XFxcXHNyY1xcXFxhcHBcXFxcYXBpXFxcXGVtYWlsXFxcXHJvdXRlLmpzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9lbWFpbC9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2VtYWlsXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9lbWFpbC9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIkM6XFxcXFVzZXJzXFxcXGJ1emFjXFxcXFByb2plY3RzXFxcXFdvcmtcXFxcSW1wZXJpYWxMdXhcXFxcc3JjXFxcXGFwcFxcXFxhcGlcXFxcZW1haWxcXFxccm91dGUuanNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyByZXF1ZXN0QXN5bmNTdG9yYWdlLCBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcyB9ID0gcm91dGVNb2R1bGU7XG5jb25zdCBvcmlnaW5hbFBhdGhuYW1lID0gXCIvYXBpL2VtYWlsL3JvdXRlXCI7XG5mdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgIHJldHVybiBfcGF0Y2hGZXRjaCh7XG4gICAgICAgIHNlcnZlckhvb2tzLFxuICAgICAgICBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlXG4gICAgfSk7XG59XG5leHBvcnQgeyByb3V0ZU1vZHVsZSwgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIG9yaWdpbmFsUGF0aG5hbWUsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Femail%2Froute&page=%2Fapi%2Femail%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Femail%2Froute.js&appDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./src/app/api/email/route.js":
/*!************************************!*\
  !*** ./src/app/api/email/route.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var private_next_rsc_server_reference__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! private-next-rsc-server-reference */ \"(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js\");\n/* harmony import */ var private_next_rsc_action_encryption__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! private-next-rsc-action-encryption */ \"(rsc)/./node_modules/next/dist/server/app-render/encryption.js\");\n/* harmony import */ var private_next_rsc_action_encryption__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(private_next_rsc_action_encryption__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _service_mailService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../service/mailService */ \"(rsc)/./src/service/mailService.js\");\n/* harmony import */ var private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-rsc-action-validate */ \"(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js\");\n/* __next_internal_action_entry_do_not_use__ {\"bdad387085847ca8d6766ab8923fa0b73395db09\":\"POST\"} */ \n\n\n\nasync function POST(req) {\n    const data = await req.json();\n    if (!data.name || !data.contact || !data.message) return next_server__WEBPACK_IMPORTED_MODULE_2__.NextResponse.json({\n        ok: false,\n        msg: \"No name, contact or message specified\"\n    });\n    const message = `New quote request from: ${data.name} \\nContact: ${data.contact} \\nDetails: ${data.message}`;\n    const response = await (0,_service_mailService__WEBPACK_IMPORTED_MODULE_3__.sendMail)(message);\n    // console.log(response)\n    if (!response.error) return next_server__WEBPACK_IMPORTED_MODULE_2__.NextResponse.json({\n        ok: true,\n        msg: \"Sent succesfuly\"\n    });\n    return next_server__WEBPACK_IMPORTED_MODULE_2__.NextResponse.json({\n        ok: false,\n        msg: \"A server error has accoured\",\n        error: response.error\n    });\n}\n\n(0,private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_4__.ensureServerEntryExports)([\n    POST\n]);\n(0,private_next_rsc_server_reference__WEBPACK_IMPORTED_MODULE_0__.registerServerReference)(\"bdad387085847ca8d6766ab8923fa0b73395db09\", POST);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9lbWFpbC9yb3V0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFFMkM7QUFDYTtBQUVqRCxlQUFlRSxLQUFLQyxHQUFHO0lBRTFCLE1BQU1DLE9BQU8sTUFBTUQsSUFBSUUsSUFBSTtJQUMzQixJQUFJLENBQUNELEtBQUtFLElBQUksSUFBSSxDQUFDRixLQUFLRyxPQUFPLElBQUksQ0FBQ0gsS0FBS0ksT0FBTyxFQUFFLE9BQU9SLHFEQUFZQSxDQUFDSyxJQUFJLENBQUM7UUFBQ0ksSUFBRztRQUFNQyxLQUFJO0lBQXVDO0lBRWhJLE1BQU1GLFVBQVUsQ0FBQyx3QkFBd0IsRUFBRUosS0FBS0UsSUFBSSxDQUFDLFlBQVksRUFBRUYsS0FBS0csT0FBTyxDQUFDLFlBQVksRUFBRUgsS0FBS0ksT0FBTyxDQUFDLENBQUM7SUFDNUcsTUFBTUcsV0FBVyxNQUFNViw4REFBUUEsQ0FDM0JPO0lBRUosd0JBQXdCO0lBQ3hCLElBQUcsQ0FBQ0csU0FBU0MsS0FBSyxFQUFFLE9BQU9aLHFEQUFZQSxDQUFDSyxJQUFJLENBQUM7UUFBQ0ksSUFBRztRQUFLQyxLQUFJO0lBQWlCO0lBQzNFLE9BQU9WLHFEQUFZQSxDQUFDSyxJQUFJLENBQUM7UUFBQ0ksSUFBRztRQUFNQyxLQUFJO1FBQStCRSxPQUFNRCxTQUFTQyxLQUFLO0lBQUE7QUFDOUYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9pbXBlcmlhbC1sdXgvLi9zcmMvYXBwL2FwaS9lbWFpbC9yb3V0ZS5qcz83YzBlIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJ1xyXG5cclxuaW1wb3J0IHsgTmV4dFJlc3BvbnNlIH0gZnJvbSBcIm5leHQvc2VydmVyXCI7XHJcbmltcG9ydCB7IHNlbmRNYWlsIH0gZnJvbSBcIi4uLy4uLy4uL3NlcnZpY2UvbWFpbFNlcnZpY2VcIjtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcSl7XHJcblxyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcS5qc29uKClcclxuICAgIGlmICghZGF0YS5uYW1lIHx8ICFkYXRhLmNvbnRhY3QgfHwgIWRhdGEubWVzc2FnZSkgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHtvazpmYWxzZSxtc2c6XCJObyBuYW1lLCBjb250YWN0IG9yIG1lc3NhZ2Ugc3BlY2lmaWVkXCJ9KVxyXG5cclxuICAgIGNvbnN0IG1lc3NhZ2UgPSBgTmV3IHF1b3RlIHJlcXVlc3QgZnJvbTogJHtkYXRhLm5hbWV9IFxcbkNvbnRhY3Q6ICR7ZGF0YS5jb250YWN0fSBcXG5EZXRhaWxzOiAke2RhdGEubWVzc2FnZX1gXHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHNlbmRNYWlsKFxyXG4gICAgICAgIG1lc3NhZ2VcclxuICAgICk7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhyZXNwb25zZSlcclxuICAgIGlmKCFyZXNwb25zZS5lcnJvcikgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHtvazp0cnVlLG1zZzpcIlNlbnQgc3VjY2VzZnVseVwifSlcclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7b2s6ZmFsc2UsbXNnOlwiQSBzZXJ2ZXIgZXJyb3IgaGFzIGFjY291cmVkXCIsIGVycm9yOnJlc3BvbnNlLmVycm9yfSlcclxufSJdLCJuYW1lcyI6WyJOZXh0UmVzcG9uc2UiLCJzZW5kTWFpbCIsIlBPU1QiLCJyZXEiLCJkYXRhIiwianNvbiIsIm5hbWUiLCJjb250YWN0IiwibWVzc2FnZSIsIm9rIiwibXNnIiwicmVzcG9uc2UiLCJlcnJvciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/email/route.js\n");

/***/ }),

/***/ "(rsc)/./src/service/mailService.js":
/*!************************************!*\
  !*** ./src/service/mailService.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   sendMail: () => (/* binding */ sendMail)\n/* harmony export */ });\nvar nodemailer = __webpack_require__(/*! nodemailer */ \"(rsc)/./node_modules/nodemailer/lib/nodemailer.js\");\n//-----------------------------------------------------------------------------\nasync function sendMail(otpText) {\n    try {\n        var transporter = nodemailer.createTransport({\n            host: \"theimperiallux.com\",\n            port: 587,\n            auth: {\n                user: process.env.NODEMAILER_EMAIL,\n                pass: process.env.NODEMAILER_PW\n            },\n            tls: {\n                rejectUnauthorized: false\n            }\n        });\n        var mailOptions = {\n            from: process.env.NODEMAILER_EMAIL,\n            to: \"vgpersonalmail@gmail.com\",\n            subject: \"Quote request from ImperialLux site !\",\n            text: otpText\n        };\n        const response = await new Promise((resolve, reject)=>{\n            // send mail\n            transporter.sendMail(mailOptions, (err, response)=>{\n                if (err) {\n                    reject(err);\n                } else {\n                    resolve(response);\n                }\n            });\n        });\n    } catch (error) {\n        console.error(\"Error sending mail:\", error);\n        return {\n            error: \"Failed to send email\",\n            details: error.message,\n            error: error\n        };\n    }\n    return true;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvc2VydmljZS9tYWlsU2VydmljZS5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQ0EsSUFBSUEsYUFBYUMsbUJBQU9BLENBQUMscUVBQVk7QUFDckMsK0VBQStFO0FBQ3hFLGVBQWVDLFNBQVNDLE9BQU87SUFDcEMsSUFBSTtRQUNKLElBQUlDLGNBQWNKLFdBQVdLLGVBQWUsQ0FBQztZQUMzQ0MsTUFBTTtZQUNOQyxNQUFNO1lBQ05DLE1BQU07Z0JBQ0pDLE1BQU1DLFFBQVFDLEdBQUcsQ0FBQ0MsZ0JBQWdCO2dCQUNsQ0MsTUFBTUgsUUFBUUMsR0FBRyxDQUFDRyxhQUFhO1lBQ2pDO1lBQ0FDLEtBQUs7Z0JBQ0RDLG9CQUFvQjtZQUN4QjtRQUNGO1FBRUEsSUFBSUMsY0FBYztZQUNoQkMsTUFBTVIsUUFBUUMsR0FBRyxDQUFDQyxnQkFBZ0I7WUFDbENPLElBQUk7WUFDSkMsU0FBUztZQUNUQyxNQUFNbEI7UUFDUjtRQUNBLE1BQU1tQixXQUFXLE1BQU0sSUFBSUMsUUFBUSxDQUFDQyxTQUFTQztZQUMzQyxZQUFZO1lBQ1pyQixZQUFZRixRQUFRLENBQUNlLGFBQWEsQ0FBQ1MsS0FBS0o7Z0JBQ3RDLElBQUlJLEtBQUs7b0JBQ1BELE9BQU9DO2dCQUNULE9BQU87b0JBQ0xGLFFBQVFGO2dCQUNWO1lBQ0Y7UUFFRjtJQUNBLEVBQUUsT0FBT0ssT0FBTztRQUNkQyxRQUFRRCxLQUFLLENBQUMsdUJBQXVCQTtRQUNyQyxPQUFPO1lBQUVBLE9BQU87WUFBd0JFLFNBQVNGLE1BQU1HLE9BQU87WUFBRUgsT0FBTUE7UUFBTTtJQUM5RTtJQUNBLE9BQU87QUFDVCIsInNvdXJjZXMiOlsid2VicGFjazovL2ltcGVyaWFsLWx1eC8uL3NyYy9zZXJ2aWNlL21haWxTZXJ2aWNlLmpzPzk2OWIiXSwic291cmNlc0NvbnRlbnQiOlsiXHJcbnZhciBub2RlbWFpbGVyID0gcmVxdWlyZShcIm5vZGVtYWlsZXJcIik7XHJcbi8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRNYWlsKG90cFRleHQpIHtcclxuICB0cnkge1xyXG4gIHZhciB0cmFuc3BvcnRlciA9IG5vZGVtYWlsZXIuY3JlYXRlVHJhbnNwb3J0KHtcclxuICAgIGhvc3Q6ICd0aGVpbXBlcmlhbGx1eC5jb20nLFxyXG4gICAgcG9ydDogNTg3LFxyXG4gICAgYXV0aDoge1xyXG4gICAgICB1c2VyOiBwcm9jZXNzLmVudi5OT0RFTUFJTEVSX0VNQUlMLFxyXG4gICAgICBwYXNzOiBwcm9jZXNzLmVudi5OT0RFTUFJTEVSX1BXLFxyXG4gICAgfSxcclxuICAgIHRsczoge1xyXG4gICAgICAgIHJlamVjdFVuYXV0aG9yaXplZDogZmFsc2VcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgdmFyIG1haWxPcHRpb25zID0ge1xyXG4gICAgZnJvbTogcHJvY2Vzcy5lbnYuTk9ERU1BSUxFUl9FTUFJTCxcclxuICAgIHRvOiBcInZncGVyc29uYWxtYWlsQGdtYWlsLmNvbVwiLFxyXG4gICAgc3ViamVjdDogJ1F1b3RlIHJlcXVlc3QgZnJvbSBJbXBlcmlhbEx1eCBzaXRlICEnLFxyXG4gICAgdGV4dDogb3RwVGV4dCxcclxuICB9O1xyXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgLy8gc2VuZCBtYWlsXHJcbiAgICB0cmFuc3BvcnRlci5zZW5kTWFpbChtYWlsT3B0aW9ucywgKGVyciwgcmVzcG9uc2UpID0+IHtcclxuICAgICAgaWYgKGVycikge1xyXG4gICAgICAgIHJlamVjdChlcnIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIFxyXG4gIH0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKCdFcnJvciBzZW5kaW5nIG1haWw6JywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgZXJyb3I6ICdGYWlsZWQgdG8gc2VuZCBlbWFpbCcsIGRldGFpbHM6IGVycm9yLm1lc3NhZ2UsIGVycm9yOmVycm9yIH07XHJcbiAgfVxyXG4gIHJldHVybiB0cnVlXHJcbn1cclxuIl0sIm5hbWVzIjpbIm5vZGVtYWlsZXIiLCJyZXF1aXJlIiwic2VuZE1haWwiLCJvdHBUZXh0IiwidHJhbnNwb3J0ZXIiLCJjcmVhdGVUcmFuc3BvcnQiLCJob3N0IiwicG9ydCIsImF1dGgiLCJ1c2VyIiwicHJvY2VzcyIsImVudiIsIk5PREVNQUlMRVJfRU1BSUwiLCJwYXNzIiwiTk9ERU1BSUxFUl9QVyIsInRscyIsInJlamVjdFVuYXV0aG9yaXplZCIsIm1haWxPcHRpb25zIiwiZnJvbSIsInRvIiwic3ViamVjdCIsInRleHQiLCJyZXNwb25zZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiZXJyIiwiZXJyb3IiLCJjb25zb2xlIiwiZGV0YWlscyIsIm1lc3NhZ2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/service/mailService.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/nodemailer"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Femail%2Froute&page=%2Fapi%2Femail%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Femail%2Froute.js&appDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Cbuzac%5CProjects%5CWork%5CImperialLux&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();